# Perfect Pixel Clone

Preciso clonar este site para que fique exatamente idêntico em termos de layout, seções, espaçamentos, tipografia, cores e conteúdo. Use como base este código-fonte em HTML/CSS original e a imagem que anexei como guia visual absoluta. Recrie a estrutura inteira usando componentes limpos no React e Tailwind CSS.
Ajuste a cor principal (accent) para ser exatamente o azul #2563eb e use a fonte Raleway como está no código original.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/a8de7f12-25eb-4e85-9e35-6307036b8de7).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Cloudflare Pages

Use these build settings:

- Build command: `npm run build`
- Build output directory: `dist`
- Deploy command: leave empty (Cloudflare Pages publishes the output directory automatically)

The build prerenders the home page and copies the complete static site to
`dist/index.html`. Do not use `wrangler deploy dist/_worker.js`: this project
is deployed as static files and does not require a Worker entry point.
