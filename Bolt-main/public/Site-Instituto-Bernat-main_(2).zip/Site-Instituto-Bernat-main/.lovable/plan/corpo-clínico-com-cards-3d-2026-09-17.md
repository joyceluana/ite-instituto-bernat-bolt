# Corpo Clínico com cards 3D

## Objetivo
Substituir a seção atual de equipe por uma grade premium de cinco profissionais, usando as fotos e os dados fornecidos.

## O que será construído
- Grade responsiva com 3 colunas em telas grandes, 2 em tablets e 1 em celulares.
- Frente de cada card com foto, nome, CRO quando informado e especialidade principal.
- Verso com currículo em tópicos, rolagem interna discreta e acabamento verde profundo, dourado minimalista e neutros claros.
- Interação por hover em dispositivos com mouse e por clique/toque em qualquer dispositivo.
- Controles acessíveis por teclado, indicação visual para abrir/fechar e suporte a movimento reduzido.
- Uso das cinco fotos anexadas, otimizadas e incorporadas ao pacote estático para funcionarem no Cloudflare Pages.

## Detalhes técnicos
- Criar um componente reutilizável de card com estado individual de abertura.
- Manter a tipografia Raleway e os tokens visuais atuais do Instituto Bernat.
- Preservar a âncora `#equipe` e a navegação existente.
- Remover os cards antigos e seus dados não solicitados nesta nova composição.
- Validar compilação, fotos, interação e responsividade no navegador.
