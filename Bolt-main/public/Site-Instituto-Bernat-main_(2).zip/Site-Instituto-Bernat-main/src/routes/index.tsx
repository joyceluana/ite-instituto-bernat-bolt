import { createFileRoute } from "@tanstack/react-router";
import {
  ArrowRight, BookOpen, Camera, Check, Clock3, Eye, GraduationCap, HeartPulse,
  Instagram, Mail, MapPin, Menu, MessageCircle, Monitor, Phone, ShieldCheck,
  RotateCcw, Sparkles, Star, Target, Trophy, Users, X,
} from "lucide-react";
import { useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import logoUrl from "../assets/logo-bernat.png";
import beatrizPhoto from "../assets/team/beatriz-borba.jpg";
import amandaPhoto from "../assets/team/amanda-guimaraes.jpg";
import danielaPhoto from "../assets/team/daniela-clark.jpg";
import heltonPhoto from "../assets/team/helton-costa.jpg";
import marianaPhoto from "../assets/team/mariana-pedrosa.jpg";
import matheusPhoto from "../assets/team/matheus-veppo.jpg";
import millaPhoto from "../assets/team/milla-bernat.jpg";
import polyanaPhoto from "../assets/team/polyana-carvalho.jpg";
import receptionPhoto from "../assets/recepcao-instituto.jpg";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Instituto Bernat — Odontologia Esportiva e Integrada" },
    { name: "description", content: "O Instituto Bernat une excelência clínica, ciência e cuidado humanizado em Brasília/DF." },
    { property: "og:title", content: "Instituto Bernat — Odontologia Esportiva e Integrada" },
    { property: "og:description", content: "Excelência clínica, ciência e cuidado humanizado em Brasília/DF." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: Index,
});

const nav = [["O Instituto","instituto"],["Experiência","experiencia"],["Especialidades","especialidades"],["Tecnologias","tecnologias"],["Equipe","equipe"],["Ensino","ensino"],["Contato","contato"]];
const specialties = [
  ["🌿","Periodontia","Cuidado da gengiva e dos tecidos de suporte dos dentes."],
  ["⚡","Odontologia do Esporte","Saúde bucal integrada à performance física."],
  ["✨","Ortodontia & Invisalign","Alinhamento discreto com planejamento digital."],
  ["💎","Implantodontia","Reposição de dentes perdidos com implantes."],
  ["🔬","Endodontia","Tratamento de canal para preservar o dente natural."],
  ["🪄","Dentística Restauradora","Restaurações estéticas e funcionais."],
  ["🛡️","Clínica Geral","Prevenção, limpeza e check-up contínuo."],
  ["🩺","Cirurgias Orais","Procedimentos cirúrgicos com segurança."],
  ["🏛️","Reabilitação Oral","Reconstrução de função e estética do sorriso."],
  ["🌟","Harmonização Facial","Equilíbrio das proporções faciais."],
  ["🌙","Odontologia do Sono","Tratamento de ronco e apneia."],
  ["🧸","Odontopediatria","Cuidado acolhedor para crianças e adolescentes."],
];
const clinicians = [
  {
    name: "Dra. Milla",
    cro: "",
    specialty: "Periodontia, Implantodontia & Odontologia do Esporte",
    photo: millaPhoto,
    photoPosition: "center 28%",
    curriculum: ["Mestra em Odontologia (UnB)", "Especialista em Periodontia (São Leopoldo Mandic Brasília)", "Especialista em Implantodontia (IPESP)", "Especialista em Odontologia do Esporte (FIASP)", "Professora titular de Periodontia (UNIEURO)", "Coordenadora da Especialização em Periodontia (IOA/Brasília)", "Membro da SOBRAPI, SBEEE, ABROE e ITI", "Sócia-fundadora do PerioTraining", "CEO do Instituto Bernat"],
  },
  {
    name: "Dr. Helton Costa",
    cro: "CRO-DF 11.869",
    specialty: "Implantodontia, Prótese & Odontologia Digital",
    photo: heltonPhoto,
    photoPosition: "center 24%",
    curriculum: ["Bacharel em Odontologia (UNIEURO)", "Especialista em Implantodontia (IPESP)", "Especialista em Prótese Dentária (IPESP)", "Mestre em Odontologia (UnB)", "Doutorando em Odontologia (UnB)", "Coordenador Adjunto de Odontologia (UNIEURO)", "Coordenador de Pós-Graduação em Implantodontia (UNIEURO)", "Professor Titular de Prótese, Implantodontia e Odontologia Digital (UNIEURO)", "Professor convidado em cursos de Pós-Graduação (Prótese, Cirurgia, Dentística e Odontologia Digital)"],
  },
  {
    name: "Dra. Daniela Sampaio Carvalho Clark",
    cro: "CRO-DF 4.485",
    specialty: "Ortodontia",
    photo: danielaPhoto,
    photoPosition: "center 30%",
    curriculum: ["Especialista em Ortodontia", "Mestre em Odontologia — Ortodontia", "Membro da Diretoria da Associação Brasileira de Ortodontia (ABOR-DF)"],
  },
  {
    name: "Dra. Polyana Carvalho",
    cro: "",
    specialty: "Ortodontista, Invisalign Doctor & Harmonização Orofacial",
    photo: polyanaPhoto,
    photoPosition: "center 22%",
    curriculum: ["Graduada em Odontologia pela UnB com mais de 15 anos de experiência clínica", "Mestre em Ciências da Saúde — Prótese Bucomaxilofacial (UnB)", "Especialista em Ortodontia (ABO-Taguatinga)", "Invisalign Doctor desde 2019", "Aperfeiçoamento em Odontologia Estética e Funcional: facetas cerâmicas, restaurações, enceramento diagnóstico e HOF", "Foco em planejamento digital e abordagem acolhedora"],
  },
  {
    name: "Dra. Beatriz de Figueiredo Dornelas Furtado Borba",
    cro: "CRO-DF 17.220",
    specialty: "Clínico Geral & Estética",
    photo: beatrizPhoto,
    photoPosition: "center 18%",
    curriculum: ["Especialista em Saúde Pública e Saúde da Família", "Imersão em Laserterapia", "Imersão em Facetas de Resinas Compostas", "Imersão em Harmonização Orofacial"],
  },
  {
    name: "Dr. Matheus Veppo",
    cro: "CRO-DF 9674",
    specialty: "Implantodontia & Cirurgia Oral Menor",
    photo: matheusPhoto,
    photoPosition: "center 18%",
    curriculum: ["Graduado em Odontologia pela UnB", "Especialista em Implantodontia (IBPG)", "Mestre em Ciências da Saúde (UnB)", "Professor de Graduação (UNIEURO)", "Coordenador do curso de especialização em Implantodontia (UNIEURO)", "Habilitação em sedação consciente com óxido nitroso"],
  },
  {
    name: "Dra. Amanda Guimarães",
    cro: "CRO-DF 16186",
    specialty: "Harmonização Orofacial",
    photo: amandaPhoto,
    photoPosition: "center 18%",
    curriculum: ["Graduada em Odontologia pela UNIEURO", "Especialista em Periodontia (IOA Brasília)", "Especialista em Implantodontia (IOA Brasília)", "Especialista em Harmonização Orofacial (FaceLab)", "Residente em Estética da Face (Instituto Raulino Brasil)", "Aperfeiçoamento em Cirurgia Oral Menor (Instituto Resende)"],
  },
  {
    name: "Dra. Mariana Pedrosa",
    cro: "CRO-DF 6387",
    specialty: "Endodontia",
    photo: marianaPhoto,
    photoPosition: "center 34%",
    curriculum: ["Bacharel em Odontologia pela FOPLAC — Faculdade de Odontologia do Planalto Central", "Especialização em Endodontia pela FOPLAC", "Especialização em Harmonização Orofacial pelo Instituto Aria", "Habilitação em Ozônio pelo Instituto Aria", "Habilitação em LASER pelo Instituto Aria"],
  },
];

function SectionHead({ tag, title, children }: { tag: string; title: string; children?: ReactNode }) {
  return <div className="section-head"><span className="section-tag">{tag}</span><h2>{title}</h2>{children && <p>{children}</p>}</div>;
}
function Initials({ children }: { children: ReactNode }) { return <div className="initials">{children}</div>; }

function Index() {
  const [open, setOpen] = useState(false);
  return <main>
    <header className="site-header"><div className="nav-shell">
      <a href="#hero" className="brand" aria-label="Instituto Bernat Início"><span className="brand-mark"><img src={logoUrl} alt="Instituto Bernat" /></span><span><b>Instituto Bernat</b><small>Odontologia Esportiva e Integrada</small></span></a>
      <button className="menu-button" aria-label={open ? "Fechar menu" : "Abrir menu"} onClick={() => setOpen(!open)}>{open ? <X/> : <Menu/>}</button>
      <nav className={open ? "nav-links open" : "nav-links"} aria-label="Navegação principal">{nav.map(([label,id]) => <a key={id} href={`#${id}`} onClick={() => setOpen(false)}>{label}</a>)}<a className="header-cta" href="#contato">Agende sua consulta</a></nav>
    </div></header>

    <section className="hero" id="hero"><img className="hero-background" src={receptionPhoto} alt="Recepção do Instituto Bernat" fetchPriority="high"/><div className="hero-inner">
      <span className="badge"><Clock3 size={14}/>Excelência Clínica em Brasília · DF</span>
      <h1>Odontologia que integra ciência, esporte e saúde.</h1>
      <p>O Instituto Bernat une excelência clínica, tecnologia de ponta e cuidado humanizado para tratar a sua saúde bucal como parte essencial da saúde do seu corpo — em todas as especialidades, com destaque para <strong>Periodontia</strong>, <strong>Odontologia do Esporte</strong> e <strong>Ortodontia com Invisalign</strong>.</p>
      <div className="hero-actions"><a className="button primary" href="https://wa.me/5561996586589?text=Ol%C3%A1!%20Gostaria%20de%20agendar%20uma%20consulta%20no%20Instituto%20Bernat.">Agende sua consulta <ArrowRight size={18}/></a><a className="button secondary" href="#instituto">Conheça o Instituto</a></div>
      <span className="micro"><Check size={16}/>Liderado pela Dra. Milla Bernat · Mestra em Odontologia pela UnB</span>
    </div></section>

    <section className="pillars"><SectionHead tag="Nossos Eixos de Excelência" title="Por que o Instituto Bernat?"/><div className="three-grid">
      {[[Clock3,"Periodontia","A saúde da gengiva é a base de todo sorriso saudável. Prevenção, diagnóstico e tratamento das doenças periodontais com excelência e precisão microcirúrgica."],[Trophy,"Odontologia do Esporte","Cuidado bucal especializado para quem vive e treina o corpo, unindo proteção contra traumas, biomecânica e respiração para potencializar saúde e performance."],[Sparkles,"Ortodontia & Invisalign","Alinhamento dental discreto, preciso e confortável, com planejamento digital guiado do início ao fim para resultados harmônicos e previsíveis."]].map(([Icon,title,text]) => { const I = Icon as typeof Clock3; return <article className="pillar-card" key={String(title)}><span className="icon-box"><I/></span><h3>{String(title)}</h3><p>{String(text)}</p></article>})}
    </div></section>

    <section className="section about" id="instituto"><div className="about-grid"><div><span className="section-tag">Quem Somos</span><h2>Um novo padrão de cuidado odontológico</h2><p className="lead">Unimos ciência, esporte e odontologia de forma integrada, porque acreditamos que a saúde bucal é parte essencial da saúde do corpo inteiro. Fundado em 27 de junho de 2026, o <strong>Instituto Bernat</strong> oferece atendimento em todas as especialidades odontológicas, com foco e aprofundamento em Periodontia, Odontologia do Esporte e Ortodontia com Invisalign. Nosso trabalho é conduzido por princípios de excelência clínica, atualização científica constante e acolhimento de cada paciente de forma individualizada.</p><div className="highlight"><h4>Nossa experiência começa antes da consulta</h4><p>No Instituto Bernat, o cuidado começa antes da consulta. Nossa equipe de concierge recebe você pelo nome, escuta suas queixas com atenção e responde em minutos — porque acreditamos que um tratamento de excelência começa com um atendimento humano, ágil e acolhedor. Você não é um número de senha: você é o centro do nosso cuidado.</p></div><div className="mvv">{([
      ["Missão",Target,"Cuidar da saúde bucal como parte essencial da saúde do corpo, unindo ciência, esporte e odontologia com excelência e acolhimento."],
      ["Visão",Eye,"Ser referência nacional em odontologia integrada, reconhecida pela excelência clínica e pela formação de profissionais."],
      ["Valores",Star,"Ciência · Cuidado integral · Ética · Inovação · Ensino"]
    ] as [string, typeof Target, string][]).map(([label,Icon,text])=><div key={label}><h5><Icon/>{label}</h5><p>{text}</p></div>)}</div></div>
      <aside className="founder"><span>Liderança & Direção Clínica</span><Initials>MB</Initials><h3>Dra. Milla Bernat</h3><h4>Proprietária e CEO</h4><p>Cirurgiã-dentista há 19 anos, especialista em Periodontia, Implantodontia e Odontologia do Esporte. Mestra em Odontologia pela UnB, professora de graduação e pós-graduação, professora titular de Periodontia no UNIEURO e coordenadora da Especialização em Periodontia IOA/Brasília. Sócia-fundadora do PerioTraining: Imersão em Plástica Gengival.</p></aside>
    </div></section>

    <section className="section experience" id="experiencia"><SectionHead tag="Acolhimento Exclusivo" title="Aqui, você não é um número de senha. Você é o centro do nosso cuidado.">No Instituto Bernat, o atendimento começa muito antes da consulta. Nossa equipe de concierge recebe você pelo nome, escuta suas queixas com atenção e responde em minutos — com a agilidade que você merece e o acolhimento que faz toda a diferença.</SectionHead><div className="three-grid experience-grid">{[
      ["Resposta em até 3 min","Atendimento Consultivo no WhatsApp","Resposta em menos de 3 minutos durante o horário de atendimento. Acolhimento pelo nome, escuta atenta das suas queixas e orientação qualificada do primeiro contato ao agendamento, por consultoras treinadas nos protocolos da clínica."],
      ["Cuidado Singular","Empatia & Acolhimento","Você é compreendido em sua vulnerabilidade — sem respostas frias, sem pressa, sem julgamentos. Escuta ativa e confirmação humanizada da sua presença, do início ao fim."],
      ["Padrão Internacional","Hospitality & Concierge de Alto Luxo","Inspirados no padrão dos grandes serviços de hospitalidade (Four Seasons, Aman Resorts, Concierge VIP), tratamos cada paciente como convidado de uma experiência de prestígio."]
    ].map(x=><article className="soft-card" key={x[0]}><span className="mini-badge">{x[0]}</span><h3>{x[1]}</h3><p>{x[2]}</p></article>)}</div><div className="banner"><h3>HUMANO, NÃO ROBÔ.</h3><p>Tecnologia que aproxima. Estratégia que cuida. Atendimento que converte.</p><a className="button light" href="https://wa.me/5561996586589?text=Ol%C3%A1!%20Gostaria%20de%20falar%20com%20o%20Concierge%20do%20Instituto%20Bernat.">Falar com o Concierge <ArrowRight size={18}/></a></div></section>

    <section className="section specialties" id="especialidades"><SectionHead tag="Cuidado Abrangente" title="Atendimento completo em todas as especialidades">Do check-up à reabilitação completa, você encontra tudo em um só lugar.</SectionHead><div className="four-grid">{specialties.map((x,i)=><article className={i<3 ? "specialty featured" : "specialty"} key={x[1]}>{i<3&&<span className="feature-label">Pilar Destaque</span>}<span className="emoji">{x[0]}</span><h3>{x[1]}</h3><p>{x[2]}</p></article>)}</div></section>

    <section className="section tech" id="tecnologias"><SectionHead tag="Precisão & Conforto" title="Tecnologia a favor do seu cuidado">Investimos em tecnologia para tornar cada consulta mais confortável, precisa e segura.</SectionHead><div className="four-grid">{[[Monitor,"Scanner intraoral iTero digital","Moldagens digitais, mais conforto e precisão, sem massinha e com visualização imediata em 3D."],[Camera,"Câmera intraoral","Diagnóstico claro, com você acompanhando cada detalhe da sua saúde bucal em alta definição."],[ShieldCheck,"Sedação consciente","Tranquilidade para pacientes ansiosos e procedimentos longos, com segurança clínica absoluta."],[HeartPulse,"Biossegurança total","Protocolos rigorosos de esterilização e barreiras biológicas implementados em todas as etapas."]].map(([Icon,t,d])=>{const I=Icon as typeof Monitor;return <article className="tech-card" key={String(t)}><span className="tech-icon"><I/></span><h3>{String(t)}</h3><p>{String(d)}</p></article>})}</div></section>

    <section className="section team" id="equipe"><SectionHead tag="Corpo Clínico" title="Excelência em cada especialidade">Um corpo clínico multidisciplinar, unido por precisão técnica, ciência e cuidado verdadeiramente humano.</SectionHead><div className="clinical-grid">{clinicians.map((clinician)=><ClinicalCard key={clinician.name} clinician={clinician}/>)}</div></section>

    <section className="section education" id="ensino"><SectionHead tag="Desenvolvimento Profissional" title="Instituto Bernat Educação">Além do atendimento clínico, formamos profissionais. Cursos teóricos, práticos, hands-on e mentorias que unem prática clínica e atualização científica — incluindo o PerioTraining: Imersão em Plástica Gengival, idealizado pela Dra. Milla Bernat.</SectionHead><div className="three-grid">{[[BookOpen,"Cursos Teóricos","Fundamentação científica aprofundada, literatura atualizada e protocolos clínicos baseados em evidência para transformar a visão diagnóstica do cirurgião-dentista."],[GraduationCap,"Cursos Práticos e Hands-on","Treinamento intensivo com foco em destreza motora, simulações realísticas e o aclamado PerioTraining: Imersão em Plástica Gengival."],[Users,"Mentorias Personalizadas","Acompanhamento individual e em pequenos grupos para discussão de casos clínicos complexos, planejamento cirúrgico e evolução de carreira."]].map(([Icon,t,d])=>{const I=Icon as typeof BookOpen;return <article className="soft-card" key={String(t)}><span className="edu-icon"><I/></span><h3>{String(t)}</h3><p>{String(d)}</p></article>})}</div><div className="center"><a className="button primary" href="https://wa.me/5561996586589?text=Ol%C3%A1!%20Gostaria%20de%20saber%20mais%20sobre%20os%20cursos%20do%20Instituto%20Bernat.">Quero saber sobre os cursos <ArrowRight size={18}/></a></div></section>

    <section className="section contact" id="contato"><SectionHead tag="Contato & Atendimento" title="Agende sua avaliação">Seu sorriso e sua saúde merecem um cuidado completo.</SectionHead><div className="contact-grid"><div className="contact-card"><h3>Canais Diretos</h3><p>Entre em contato com a nossa equipe de Concierge para agendamento de consultas ou informações sobre tratamentos.</p><div className="contact-list"><Contact icon={<Phone/>} label="Telefone Fixo"><a href="tel:+556133404046">(61) 3340-4046</a></Contact><Contact icon={<MessageCircle/>} label="WhatsApp Concierge"><a href="https://wa.me/5561996586589">(61) 99658-6589</a></Contact><Contact icon={<Mail/>} label="E-mail"><a href="mailto:contato@institutobernat.com.br">contato@institutobernat.com.br</a></Contact><Contact icon={<Instagram/>} label="Instagram & Web">@institutobernat · institutobernat.com.br</Contact><Contact icon={<MapPin/>} label="Endereço">Setor SDN, Conjunto A, Sala 4003, Conjunto Nacional — Asa Norte, Brasília/DF · CEP 70077-900</Contact><Contact icon={<Clock3/>} label="Horário de Atendimento">Segunda a sexta, das 08h às 18h. Sábado e domingo: somente urgência e emergência.</Contact></div><div className="notice">ⓘ Atendimento exclusivamente particular.</div></div><div className="booking"><div><span className="badge dark-badge">Concierge WhatsApp</span><h3>Pronto para iniciar seu atendimento?</h3><p>Clique no botão abaixo para iniciar uma conversa direta com a nossa equipe no WhatsApp. Responderemos em minutos para organizar o seu horário.</p><ul><li><Check/>Atendimento humano e escuta atenta</li><li><Check/>Agilidade e pontualidade no agendamento</li><li><Check/>Privacidade, discrição e alto padrão</li></ul></div><a className="whatsapp" href="https://wa.me/5561996586589?text=Ol%C3%A1!%20Gostaria%20de%20agendar%20uma%20consulta%20no%20Instituto%20Bernat."><MessageCircle/>Agendar pelo WhatsApp</a></div></div></section>

    <footer><div className="footer-grid"><div><h3>Instituto Bernat</h3><span>Odontologia Esportiva e Integrada</span><p>Ciência, esporte e odontologia integrados para a sua saúde.</p><small>Fundado em 27 de junho de 2026 · Brasília/DF</small></div><div><h4>Navegação</h4>{nav.map(([l,id])=><a key={id} href={`#${id}`}>{l}</a>)}</div><div><h4>Contato</h4><p><b>Telefone:</b> (61) 3340-4046<br/><b>WhatsApp:</b> (61) 99658-6589<br/><b>E-mail:</b> contato@institutobernat.com.br<br/><b>Instagram:</b> @institutobernat</p></div></div><div className="footer-bottom"><i>Este site tem caráter informativo e não substitui uma consulta odontológica.</i><span>© 2026 Instituto Bernat. Todos os direitos reservados.</span></div></footer>
    <a className="floating" href="https://wa.me/5561996586589?text=Ol%C3%A1!%20Gostaria%20de%20agendar%20uma%20consulta%20no%20Instituto%20Bernat." aria-label="Abrir WhatsApp para agendamento"><MessageCircle/></a>
  </main>;
}

function Contact({icon,label,children}:{icon:ReactNode;label:string;children:ReactNode}) { return <div className="contact-item"><span>{icon}</span><div><small>{label}</small><p>{children}</p></div></div>; }

type Clinician = (typeof clinicians)[number];

function ClinicalCard({ clinician }: { clinician: Clinician }) {
  const [flipped, setFlipped] = useState(false);
  return <article className={`clinical-card${flipped ? " is-flipped" : ""}`}>
    <div className="clinical-card-inner">
      <div className="clinical-face clinical-front">
        <div className="clinician-photo-wrap"><img src={clinician.photo} alt={`Retrato de ${clinician.name}`} loading="lazy" style={{ objectPosition: clinician.photoPosition }}/></div>
        <div className="clinician-summary">
          {clinician.cro && <span className="clinician-cro">{clinician.cro}</span>}
          <h3>{clinician.name}</h3>
          <p>{clinician.specialty}</p>
          <Button type="button" variant="ghost" className="clinical-flip-button" onClick={() => setFlipped(true)} aria-label={`Ver currículo de ${clinician.name}`}>Ver currículo <ArrowRight/></Button>
        </div>
      </div>
      <div className="clinical-face clinical-back" aria-hidden={!flipped}>
        <div className="clinical-back-head"><div><span>Formação & experiência</span><h3>{clinician.name}</h3></div><Button type="button" variant="ghost" size="icon" className="clinical-close" onClick={() => setFlipped(false)} aria-label={`Voltar ao perfil de ${clinician.name}`}><RotateCcw/></Button></div>
        <div className="clinical-curriculum"><ul>{clinician.curriculum.map((item)=><li key={item}>{item}</li>)}</ul></div>
        <Button type="button" variant="ghost" className="clinical-return" onClick={() => setFlipped(false)}><RotateCcw/> Voltar ao perfil</Button>
      </div>
    </div>
  </article>;
}
