import { access, cp, mkdir, rm } from "node:fs/promises";
import { join } from "node:path";

const root = process.cwd();
const clientDir = join(root, "dist", "client");
const clientIndex = join(clientDir, "index.html");
const rootIndex = join(root, "dist", "index.html");

try {
  await access(clientIndex);
} catch {
  throw new Error(
    "A exportação estática não encontrou dist/client/index.html. Verifique se a rota / foi pré-renderizada.",
  );
}

await mkdir(join(root, "dist"), { recursive: true });
await cp(clientDir, join(root, "dist"), { recursive: true, force: true });
await access(rootIndex);

// Remove artefatos de servidor: o site publicado é apenas estático.
for (const extra of ["client", "server", "nitro.json"]) {
  await rm(join(root, "dist", extra), { recursive: true, force: true });
}

console.log("[static-export] Site pronto em dist/index.html");
