# Roadmap

- [x] Gerar exportação estática pura em `dist` com `index.html` na raiz
- [x] Validar `npm run build` e os caminhos dos arquivos publicados
- [x] Informar a configuração correta de deploy no Cloudflare Pages
- [x] Inserir a recepção como fundo da abertura sem alterar sua estrutura
- [x] Adicionar Amanda, Mariana e Matheus ao Corpo Clínico com os currículos fornecidos
- [x] Validar a apresentação em computador e celular e a exportação final
